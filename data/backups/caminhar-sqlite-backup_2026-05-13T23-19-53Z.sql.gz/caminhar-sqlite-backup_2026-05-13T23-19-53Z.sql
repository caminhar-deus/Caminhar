PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        role TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
INSERT INTO users VALUES(1,'admin','$2b$10$KpzAFgfw1mRya7T/F.Kk6OBBJvc5VZa03DeV1kdbBNb2.i/tPh1v6','admin','2026-01-26 19:20:30','2026-01-26 19:20:30');
CREATE TABLE settings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        key TEXT UNIQUE NOT NULL,
        value TEXT NOT NULL,
        type TEXT NOT NULL,
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
INSERT INTO settings VALUES(1,'site_title','O Caminhar com Deus','string','Website title','2026-01-26 19:20:30','2026-01-27 04:46:31');
INSERT INTO settings VALUES(2,'site_subtitle','Reflexões e ensinamentos sobre a fé, espiritualidade e a jornada cristã','string','Website subtitle','2026-01-26 19:20:30','2026-01-26 19:20:30');
INSERT INTO settings VALUES(3,'test_config_1769484172329','updated_test_value','string','Configuração de teste atualizada','2026-01-27 03:22:52','2026-01-27 03:22:52');
CREATE TABLE images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        filename TEXT NOT NULL,
        path TEXT NOT NULL,
        type TEXT NOT NULL,
        size INTEGER,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        uploaded_by INTEGER,
        FOREIGN KEY (uploaded_by) REFERENCES users(id)
      );
CREATE TABLE categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL
      );
INSERT INTO categories VALUES(1,'Espiritualidade','espiritualidade');
INSERT INTO categories VALUES(2,'Vida Cristã','vida-crista');
CREATE TABLE tags (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL
      );
INSERT INTO tags VALUES(1,'Fé','fe');
INSERT INTO tags VALUES(2,'Oração','oracao');
CREATE TABLE posts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        excerpt TEXT,
        content TEXT,
        image_url TEXT,
        published BOOLEAN DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
INSERT INTO posts VALUES(1,'A Importância da Oração Diária','importancia-da-oracao','Descubra como a oração pode transformar sua caminhada diária com Deus e trazer paz ao seu coração.','Conteúdo completo do artigo...','/api/placeholder-image?text=Oracao',1,'2026-01-27 18:47:45','2026-01-27 18:47:45');
INSERT INTO posts VALUES(2,'Caminhando com Fé em Tempos Difíceis','caminhando-com-fe','Em momentos de incerteza, a fé é a âncora que nos mantém firmes. Veja reflexões sobre perseverança.','Conteúdo completo do artigo...','/api/placeholder-image?text=Fe',1,'2026-01-27 18:47:45','2026-01-27 18:47:45');
CREATE TABLE post_categories (
        post_id INTEGER,
        category_id INTEGER,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE,
        FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE,
        PRIMARY KEY (post_id, category_id)
      );
INSERT INTO post_categories VALUES(1,1);
INSERT INTO post_categories VALUES(2,2);
CREATE TABLE post_tags (
        post_id INTEGER,
        tag_id INTEGER,
        FOREIGN KEY(post_id) REFERENCES posts(id) ON DELETE CASCADE,
        FOREIGN KEY(tag_id) REFERENCES tags(id) ON DELETE CASCADE,
        PRIMARY KEY (post_id, tag_id)
      );
INSERT INTO post_tags VALUES(1,2);
INSERT INTO post_tags VALUES(2,1);
CREATE TABLE musicas (id INTEGER PRIMARY KEY AUTOINCREMENT, titulo TEXT NOT NULL, artista TEXT NOT NULL, url_imagem TEXT, url_spotify TEXT NOT NULL, publicado BOOLEAN DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
INSERT INTO musicas VALUES(1,'Teste Música','Teste Artista',NULL,'https://open.spotify.com/intl-pt/track/6ts62HxXhbwQASHKVX4SMU',1,'2026-02-15 15:05:32','2026-02-15 15:05:32');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('users',1);
INSERT INTO sqlite_sequence VALUES('settings',3);
INSERT INTO sqlite_sequence VALUES('categories',2);
INSERT INTO sqlite_sequence VALUES('tags',2);
INSERT INTO sqlite_sequence VALUES('posts',2);
INSERT INTO sqlite_sequence VALUES('musicas',1);
COMMIT;
