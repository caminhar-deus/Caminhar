--
-- PostgreSQL database dump
--

\restrict TpUEJYlIF6BWdY50GpBoHIOQEprh02ccUtdBW6eOjiZWAPSJRRxfv9V96fzifcV

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    path character varying(500) NOT NULL,
    type character varying(50),
    size integer,
    user_id integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_id_seq OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: musicas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.musicas (
    id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    artista character varying(255),
    url_spotify character varying(255) NOT NULL,
    descricao text,
    publicado boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.musicas OWNER TO postgres;

--
-- Name: musicas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.musicas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.musicas_id_seq OWNER TO postgres;

--
-- Name: musicas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.musicas_id_seq OWNED BY public.musicas.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title character varying(255) NOT NULL,
    slug character varying(255) NOT NULL,
    excerpt text,
    content text,
    image_url character varying(255),
    published boolean DEFAULT false,
    views integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    key character varying(255) NOT NULL,
    value text,
    type character varying(50),
    description text,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    role character varying(50) DEFAULT 'user'::character varying
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: videos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.videos (
    id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    url_youtube character varying(255) NOT NULL,
    descricao text,
    publicado boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.videos OWNER TO postgres;

--
-- Name: videos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.videos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.videos_id_seq OWNER TO postgres;

--
-- Name: videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.videos_id_seq OWNED BY public.videos.id;


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: musicas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musicas ALTER COLUMN id SET DEFAULT nextval('public.musicas_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: videos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videos ALTER COLUMN id SET DEFAULT nextval('public.videos_id_seq'::regclass);


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, filename, path, type, size, user_id, created_at) FROM stdin;
\.


--
-- Data for Name: musicas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.musicas (id, titulo, artista, url_spotify, descricao, publicado, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, title, slug, excerpt, content, image_url, published, views, created_at, updated_at) FROM stdin;
1	Mateus Capítulos 6 e 7	mateus-capitulos-6-e-7	Leitura Bíblica Mateus Capítulos 6 e 7	1 Guardai-vos de fazer vossas boas obras diante dos homens, para serdes vistos por eles. Do contrário, não tereis recompensa junto de vosso Pai que está no céu.\n2 Quando, pois, dás esmola, não toques a trombeta diante de ti, como fazem os hipócritas nas sinagogas e nas ruas, para serem louvados pelos homens. Em verdade eu vos digo: já receberam sua recompensa.\n3 Quando deres esmola, que tua mão esquerda não saiba o que fez a direita.\n4 Assim, a tua esmola se fará em segredo; e teu Pai, que vê o escondido, irá recompensar-te.\n5 Quando orardes, não façais como os hipócritas, que gostam de orar de pé nas sinagogas e nas esquinas das ruas, para serem vistos pelos homens. Em verdade eu vos digo: já receberam sua recompensa.\n6 Quando orares, entra no teu quarto, fecha a porta e ora ao teu Pai em segredo; e teu Pai, que vê num lugar oculto, te recompensará.\n7 Nas vossas orações, não multipliqueis as palavras, como fazem os pagãos que julgam que serão ouvidos à força de palavras.\n8 Não os imiteis, porque vosso Pai sabe o que vos é necessário, antes que vós lho peçais.\n9 Eis como deveis rezar: PAI NOSSO, que estais no céu, santificado seja o vosso nome;\n10 venha a nós o vosso Reino; seja feita a vossa vontade, assim na terra como no céu.\n11 O pão nosso de cada dia nos dai hoje;\n12 perdoai-nos as nossas ofensas, assim como nós perdoamos aos que nos ofenderam;\n13 e não nos deixeis cair em tentação, mas livrai-nos do mal.\n14 Porque, se perdoardes aos homens as suas ofensas, vosso Pai celeste também vos perdoará.\n15 Mas, se não perdoardes aos homens, tampouco vosso Pai vos perdoará.\n16 Quando jejuardes, não tomeis um ar triste como os hipócritas, que mostram um semblante abatido para manifestar aos homens que jejuam. Em verdade eu vos digo: já receberam sua recompensa.\n17 Quando jejuares, perfuma a tua cabeça e lava o teu rosto.\n18 Assim, não parecerá aos homens que jejuas, mas somente a teu Pai que está presente ao oculto; e teu Pai, que vê num lugar oculto, te recompensará.\n19 “Não ajunteis para vós tesouros na terra, onde a ferrugem e as traças corroem, onde os ladrões furtam e roubam.\n20 Ajuntai para vós tesouros no céu, onde não os consomem nem as traças nem a ferrugem, e os ladrões não furtam nem roubam.\n21 Porque onde está o teu tesouro, lá também está teu coração.\n22 O olho é a luz do corpo. Se teu olho é são, todo o teu corpo será iluminado.\n23 Se teu olho estiver em mau estado, todo o teu corpo estará nas trevas. Se a luz que está em ti são trevas, quão espessas deverão ser as trevas!”\n24 “Ninguém pode servir a dois senhores, porque ou odiará a um e amará o outro, ou se dedicará a um e desprezará o outro. Não podeis servir a Deus e à riqueza.\n25 Portanto, eis que vos digo: não vos preocupeis por vossa vida, pelo que comereis, nem por vosso corpo, pelo que vestireis. A vida não é mais do que o alimento e o corpo não é mais que as vestes?\n26 Olhai as aves do céu: não semeiam nem ceifam, nem recolhem nos celeiros e vosso Pai celeste as alimenta. Não valeis vós muito mais que elas?\n27 Qual de vós, por mais que se esforce, pode acrescentar um só côvado à duração de sua vida?\n28 E por que vos inquietais com as vestes? Considerai como crescem os lírios do campo; não trabalham nem fiam.\n29 Entretanto, eu vos digo que o próprio Salomão no auge de sua glória não se vestiu como um deles.\n30 Se Deus veste assim a erva dos campos, que hoje cresce e amanhã será lançada ao fogo, quanto mais a vós, homens de pouca fé?\n31 Não vos aflijais, nem digais: Que comeremos? Que beberemos? Com que nos vestiremos?\n32 São os pagãos que se preocupam com tudo isso. Ora, vosso Pai celeste sabe que necessitais de tudo isso.\n33 Buscai em primeiro lugar o Reino de Deus e a sua justiça e todas estas coisas vos serão dadas em acréscimo.\n34 Não vos preocupeis, pois, com o dia de amanhã: o dia de amanhã terá as suas preocupações próprias. A cada dia basta o seu cuidado.\nMateus Capítulo 6\n\n\n1 Não julgueis, e não sereis julgados.\n2 Porque do mesmo modo que julgardes, sereis também vós julgados e, com a medida com que tiverdes medido, também vós sereis medidos.\n3 Por que olhas a palha que está no olho do teu irmão e não vês a trave que está no teu?\n4 Como ousas dizer a teu irmão: Deixa-me tirar a palha do teu olho, quando tens uma trave no teu?\n5 Hipócrita! Tira primeiro a trave de teu olho e assim verás para tirar a palha do olho do teu irmão.\n6 Não lanceis aos cães as coisas santas, não atireis aos porcos as vossas pérolas, para que não as calquem com os seus pés, e, voltando-se contra vós, vos despedacem.\n7 Pedi e se vos dará. Buscai e achareis. Batei e vos será aberto.\n8 Porque todo aquele que pede, recebe. Quem busca, acha. A quem bate, se abrirá.\n9 Quem dentre vós dará uma pedra a seu filho, se este lhe pedir pão?\n10 E, se lhe pedir um peixe, lhe dará uma serpente?\n11 Se vós, pois, que sois maus, sabeis dar boas coisas a vossos filhos, quanto mais vosso Pai celeste dará boas coisas aos que lhe pedirem.\n12 Tudo o que quereis que os homens vos façam, fazei-o vós a eles. Esta é a Lei e os profetas.\n13 Entrai pela porta estreita, porque larga é a porta e espaçoso o caminho que conduz à perdição e numerosos são os que por aí entram.\n14 Estreita, porém, é a porta e apertado o caminho da vida e raros são os que o encontram.\n15 Guardai-vos dos falsos profetas. Eles vêm a vós disfarçados de ovelhas, mas por dentro são lobos arrebatadores.\n16 Pelos seus frutos os conhecereis. Colhem-se, porventura, uvas dos espinhos e figos dos abrolhos?\n17 Toda árvore boa dá bons frutos; toda árvore má dá maus frutos.\n18 Uma árvore boa não pode dar maus frutos; nem uma árvore má, bons frutos.\n19 Toda árvore que não der bons frutos será cortada e lançada ao fogo.\n20 Pelos seus frutos os conhecereis.\n21 Nem todo aquele que me diz: Senhor, Senhor, entrará no Reino dos Céus, mas sim aquele que faz a vontade de meu Pai, que está nos céus.\n22 Muitos me dirão naquele dia: Senhor, Senhor, não pregamos nós em vosso nome, e não foi em vosso nome que expulsamos os demônios e fizemos muitos milagres?\n23 E, no entanto, eu lhes direi: Nunca vos conheci. Retirai-vos de mim, operários maus!.\n24 Aquele, pois, que ouve estas minhas palavras e as põe em prática é semelhante a um homem prudente, que edificou sua casa sobre a rocha.\n25 Caiu a chuva, vieram as enchentes, sopraram os ventos e investiram contra aquela casa; ela, porém, não caiu, porque estava edificada na rocha.\n26 Mas aquele que ouve as minhas palavras e não as põe em prática é semelhante a um homem insensato, que construiu sua casa na areia.\n27 Caiu a chuva, vieram as enchentes, sopraram os ventos e investiram contra aquela casa; ela caiu e grande foi a sua ruína.\n28 Quando Jesus terminou o discurso, a multidão ficou impressionada com a sua doutrina.\n29 Com efeito, ele a ensinava como quem tinha autoridade e não como os seus escribas.\nMateus Capítulo 7	/uploads/post-image-1772105143883.png	t	0	2026-02-26 08:25:46.849579-03	2026-02-26 08:25:46.849579-03
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (key, value, type, description, updated_at) FROM stdin;
home_image_url	/uploads/hero-image-1772141705599.webp	image	Imagem principal da home	2026-02-26 18:35:05.606941
site_title	O Caminhar com Deus	string	Website title	2026-02-26 18:35:12.984771
site_subtitle	Reflexões e ensinamentos sobre a fé, espiritualidade e a jornada cristã	string	Website subtitle	2026-02-26 18:35:12.997064
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, created_at, role) FROM stdin;
1	admin	$2b$10$zvAqSVk1zUGNgkxjwal.AOar3HNvGaVbxdjtvL1UZ/tdxvXHeyK/W	2026-02-26 08:24:04.615182	admin
\.


--
-- Data for Name: videos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.videos (id, titulo, url_youtube, descricao, publicado, created_at, updated_at) FROM stdin;
\.


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id_seq', 1, false);


--
-- Name: musicas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.musicas_id_seq', 79, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_id_seq', 25, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.videos_id_seq', 23, true);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: musicas musicas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.musicas
    ADD CONSTRAINT musicas_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_key UNIQUE (slug);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: videos videos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.videos
    ADD CONSTRAINT videos_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict TpUEJYlIF6BWdY50GpBoHIOQEprh02ccUtdBW6eOjiZWAPSJRRxfv9V96fzifcV

