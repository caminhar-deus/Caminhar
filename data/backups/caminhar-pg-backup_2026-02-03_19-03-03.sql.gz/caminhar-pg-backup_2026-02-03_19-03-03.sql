--
-- PostgreSQL database dump
--

\restrict KbwN1DHhpCkhD9H7AaGv4lxDB3kqCHOWnfyfa5TnIvKUO6acsLsovmW0Tzud20b

-- Dumped from database version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.11 (Ubuntu 16.11-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: images; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.images (
    id integer NOT NULL,
    filename text NOT NULL,
    path text NOT NULL,
    type text,
    size integer,
    user_id integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.images OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.images_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.images_id_seq OWNER TO postgres;

--
-- Name: images_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.images_id_seq OWNED BY public.images.id;


--
-- Name: posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.posts (
    id integer NOT NULL,
    title text NOT NULL,
    slug text NOT NULL,
    excerpt text,
    content text,
    image_url text,
    published boolean DEFAULT false,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.posts OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.posts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.posts_id_seq OWNER TO postgres;

--
-- Name: posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.posts_id_seq OWNED BY public.posts.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.settings (
    key text NOT NULL,
    value text,
    type text,
    description text,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.settings OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username text NOT NULL,
    password text NOT NULL,
    role text DEFAULT 'user'::text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: images id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images ALTER COLUMN id SET DEFAULT nextval('public.images_id_seq'::regclass);


--
-- Name: posts id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts ALTER COLUMN id SET DEFAULT nextval('public.posts_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: images; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.images (id, filename, path, type, size, user_id, created_at) FROM stdin;
1	hero-image-1770074005656.png	/uploads/hero-image-1770074005656.png	hero	563559	1	2026-02-02 20:13:25.667837-03
2	post-image-1770074111863.png	/uploads/post-image-1770074111863.png	post	2030551	1	2026-02-02 20:15:11.911878-03
3	post-image-1770074299091.png	/uploads/post-image-1770074299091.png	post	2030551	1	2026-02-02 20:18:19.105599-03
4	post-image-1770074697743.png	/uploads/post-image-1770074697743.png	post	2030551	1	2026-02-02 20:24:57.758087-03
\.


--
-- Data for Name: posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.posts (id, title, slug, excerpt, content, image_url, published, created_at, updated_at) FROM stdin;
1	TESTE 02	teste-03	Teste 04	Teste 05	/uploads/cmvav6hnqefi27ko3hqdjdcrq.png	t	2026-02-02 20:59:13.614403-03	2026-02-03 15:42:51.778471-03
2	Teste 10	teste-11	Teste 12	Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13, Teste 13.	/uploads/post-image-1770146603972.webp	t	2026-02-03 16:23:26.625105-03	2026-02-03 16:23:26.625105-03
3	Teste 20	teste-21	Teste 22	Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, Teste 23, 	/uploads/post-image-1770150055612.png	t	2026-02-03 17:20:57.986374-03	2026-02-03 17:20:57.986374-03
4	Teste 30	teste-31	Teste 32	Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, Teste 33, 	/uploads/post-image-1770150880114.png	t	2026-02-03 17:34:42.662403-03	2026-02-03 17:34:42.662403-03
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.settings (key, value, type, description, updated_at) FROM stdin;
site_image	/uploads/ze0kcjb2m4zv60u4wpppo6ast.png	image	Main site image	2026-02-02 20:32:46.242186-03
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, username, password, role, created_at) FROM stdin;
1	admin	$2b$10$S0G.N.2Kzmbbo4rIufiBT.2NEUcE6yuDFvnJ9qn6pmKnvTkwSry/2	admin	2026-02-02 19:10:32.2084-03
\.


--
-- Name: images_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.images_id_seq', 4, true);


--
-- Name: posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.posts_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: images images_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_pkey PRIMARY KEY (id);


--
-- Name: posts posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_pkey PRIMARY KEY (id);


--
-- Name: posts posts_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.posts
    ADD CONSTRAINT posts_slug_key UNIQUE (slug);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (key);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: images images_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.images
    ADD CONSTRAINT images_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict KbwN1DHhpCkhD9H7AaGv4lxDB3kqCHOWnfyfa5TnIvKUO6acsLsovmW0Tzud20b

